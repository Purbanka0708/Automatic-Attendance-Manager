# Automatic-Attendance-Manager
• Performed a Python-based facial recognition system using dlib’s ResNet model in PyCharm IDE for accurate face
detection and recognition.<br>
• Integrated real-time webcam feed and OpenCV for video processing to identify known individuals from stored images.<br>
• Applied a CSV logging system in Python to record attendance upon recognizing known faces, ensuring timestamped entries.<br>
